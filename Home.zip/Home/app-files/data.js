var APP_DATA = {
  "scenes": [
    {
      "id": "0-the-grand-kremlin-palace-moscow-the-hall-of-the-order-of-st-andrew-pwnbrg",
      "name": "the-grand-kremlin-palace-moscow-the-hall-of-the-order-of-st-andrew-PWNBRG",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 750,
      "initialViewParameters": {
        "yaw": 0.0035050821851854153,
        "pitch": -0.06290332223863082,
        "fov": 1.4715702818443972
      },
      "linkHotspots": [
        {
          "yaw": 3.1393152819076313,
          "pitch": -0.12220358784702512,
          "rotation": 0,
          "target": "1-free-3d-interior-360-scene-share-by-3darcshop-7"
        },
        {
          "yaw": 0.0029710693042552805,
          "pitch": -0.06097715647260493,
          "rotation": 0,
          "target": "2-free-3d-interior-360-scene-share-by-3darcshop-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-free-3d-interior-360-scene-share-by-3darcshop-7",
      "name": "Free-3D-INTERIOR-360-Scene-share-by-3DARCSHOP-7",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 256,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.9488501216953402,
          "pitch": 0.07313432618653692,
          "rotation": 0,
          "target": "0-the-grand-kremlin-palace-moscow-the-hall-of-the-order-of-st-andrew-pwnbrg"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-free-3d-interior-360-scene-share-by-3darcshop-2",
      "name": "Free-3D-INTERIOR-360-Scene-share-by-3DARCSHOP-2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 256,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.8406469037215842,
          "pitch": -0.006213775795066212,
          "rotation": 0,
          "target": "0-the-grand-kremlin-palace-moscow-the-hall-of-the-order-of-st-andrew-pwnbrg"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
